#Soil_society

# -*- coding: utf-8 -*-
import scrapy
import urllib.parse
from news_project.middlewares import Deal_Content
from news_project.items import NewsProjectItem

class Soil_society(scrapy.Spider):
    name = 'Soil_society'
    allowed_domains = ['www.mnr.gov.cn']    #允许的页面最好不要定义  http://  这样的

    start_urls = ['http://www.mnr.gov.cn/']

    #中华人民共和国自然资源部

    def parse(self, response):
        # 获取id 或者pid
        id, pid = Deal_Content.sql_read(response.url)
        self.logger.info("wakak")   ##LOG_ENABLED=False  #LOG_ENABLED 默认: True，启用logging   当log_enabled = True的时候才能执行这句
        # 列表页面的 url
        home_url = response.xpath("//div[@class='gk_nei_bottom_l fl']/ul//a/@href").extract()

        #标题
        title = response.xpath("//div[@class='gk_nei_bottom_l fl']/ul//a/@title").extract()

        #时间
        #time = response.xpath("//div[@class='m-lists']//div[@class='time']//text()").extract()

        j = 0
        for url in home_url:
            detail_url = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
            print("详细页面的网址,:", detail_url)
            yield scrapy.Request(url=detail_url, callback=self.detail_parse, meta={'id': id, 'pid': pid,'title':title[j]},dont_filter=True)  # 进入详细页面
            j += 1

    def detail_parse(self, response):

        item = NewsProjectItem()
        meta = response.meta

        # 标题
        item['title'] = meta['title']
        title = item['title']
        print('标题:', item['title'])

        # 标题时间   //div[@class='detail-from']/text()
        item['time'] = response.xpath("//div[@class='rack ak47']//tr[4]/td[2]/text()").extract_first()
        print('标题时间:', item['time'])

        # 标题的url
        item['title_url'] = response.url
        print('标题的url', item['title_url'])

        # id
        item['id'] = 179
        print("id:", item['id'])

        # pid
        item['pid'] = 14
        print("pid:", item['pid'])

        # 详细页面的内容

        etree = response.xpath('//div[@class="Custom_UnionStyle"]')
        tagContet = etree.extract()
        tagContet = ''.join(tagContet)

        content = etree.xpath('.//text()').extract()
        content = ''.join(content)
        img_urls = etree.xpath('.//img/@src').extract()

        img_urls_dict = {}
        for url in img_urls:
            if "http://" not in url:
                url1 = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
                img_urls_dict[url] = url1

        print("*******img_urls_dict****", img_urls_dict)
        item['content'], item['tags'] = Deal_Content.handleText(content, tagContet, img_urls_dict, title)
        print("************item['tags']********************", item['tags'])

        # print(self.p)
        item['type_cn'] = None

        # #news    新闻来源、是那一个网站， 主页
        item['news'] = '中华人民共和国自然资源部'

        # type_no 就是 id
        item['type_no'] = None

        print(item)
        yield item