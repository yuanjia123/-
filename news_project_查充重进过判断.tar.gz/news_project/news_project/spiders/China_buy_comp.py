#China_buy_comp


import scrapy
import urllib.parse
from news_project.middlewares import Deal_Content
from news_project.items import NewsProjectItem

class China_buy_comp(scrapy.Spider):
    name = 'China_buy_comp'
    allowed_domains = ['www.ma-china.com']    #允许的页面最好不要定义  http://  这样的
    start_urls = ['http://www.ma-china.com/list.asp?classid=4']

    #陕西省山东商会
    def parse(self, response):

        id, pid = Deal_Content.sql_read(response.url)

        home_url = response.xpath("//ul[@class='newslist']//li/a/@href").extract()

        # 标题
        title = response.xpath("//ul[@class='newslist']//li/a/@title").extract()

        # 时间
        #time = response.xpath("//ul[@class='q']//span[@class='int-date']//b[@class='number']/text()").extract()

        j = 0
        for url in home_url:
            detail_url = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
            yield scrapy.Request(url=detail_url, callback=self.detail_parse,meta={'title':title[j],'id': id, 'pid': pid},dont_filter=True)  # 进入详细页面   dont_filter=True不重复进入访问过的页面
            j += 1


    def detail_parse(self,response):
        item = NewsProjectItem()
        meta = response.meta

        item['id'] = meta['id']

        item['pid'] = meta['pid']

        # 首页的url
        item['url'] = self.start_urls
        print("首页的url",item['url'])

        # 标题
        title = meta['title']
        item['title'] = title
        print('标题',item['title'])

        # 标题的url
        item['title_url'] = response.url
        print('标题的url',item['title_url'])

        # 标题时间
        item['time'] = response.xpath("//div[@class='itemss']/text()").extract_first()
        print('标题时间',item['time'])

#----------------------------------------------------------------------------------------------------
        #详细页面的内容
        etree = response.xpath("//div[@class='content']")
        tagContet = etree.extract()
        tagContet = ''.join(tagContet)

        content = etree.xpath('.//text()').extract()
        content = ''.join(content)
        img_urls = etree.xpath('.//img/@src').extract()

        img_urls_dict = {}
        for url in img_urls:
            if "http://" not in url:
                url1 = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
                img_urls_dict[url] = url1

        print("*******img_urls****", img_urls_dict)
        item['content'], item['tags'] = Deal_Content.handleText(content, tagContet,img_urls_dict, title)
        print("************item['tags']********************", item['tags'])

        item['type_cn'] = '协会'

        # #news    新闻来源、是那一个网站， 主页
        item['news'] = '全联并购公会'

        # type_no 就是 id
        item['type_no'] = 34

        #新增字段
        item['association_id'] = 190
        yield item
