# -*- coding: utf-8 -*-
import scrapy
import urllib.parse
from news_project.middlewares import Deal_Content
from news_project.items import NewsProjectItem

class China_aviation(scrapy.Spider):
    name = 'China_aviation'
    #allowed_domains = ['www.cannews.com']
    start_urls = ['http://app.finance.china.com.cn/stock/cate/detail.php?symbol=400116024']

    #中国财经首页
    def parse(self, response):
        #获取id 或者pid
        id, pid = Deal_Content.sql_read(response.url)
        print("id {} pid {}".format(id,pid))
        #列表页面的 url
        home_url = response.xpath("//ul[@class='RightCol03_list']//li//a/@href").extract()
        print("打印标题home_url", home_url)

        #标题
        title = response.xpath("//ul[@class='RightCol03_list']//li//a/text()").extract()
        print("打印标题title",title)
        #时间
        time = response.xpath("//ul[@class='RightCol03_list']//li//span/text()").extract()
        print("打印标题时间", time)
        j = 0
        for url in home_url:
            detail_url = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
            yield scrapy.Request(url=detail_url, callback=self.detail_parse,meta={'time': time[j], "title": title[j], 'id': id,'pid': pid},dont_filter=True)  # 进入详细页面   dont_filter=True不重复进入访问过的页面
            j += 1


    def detail_parse(self,response):

        item = NewsProjectItem()
        meta = response.meta

        #标题
        item['title'] = meta['title']
        title = meta['title']
        print('标题:', item['title'])

        #标题时间
        item['time'] = meta['time']
        print('标题时间:',item['time'])

        # 标题的url
        item['title_url'] = response.url
        print('标题的url',item['title_url'])

        #id
        item['id'] = 169
        print("id:",item['id'])

        #pid
        item['pid'] = 10
        print("pid:",item['pid'])

        # 详细页面的内容
        etree = response.xpath('//div[@id="fontzoom"]')
        tagContet = etree.extract()
        tagContet = ''.join(tagContet)

        content = etree.xpath('.//text()').extract()
        content = ''.join(content)
        img_urls = etree.xpath('.//img/@src').extract()

        img_urls_dict = {}
        for url in img_urls:
            if "http://网站" not in url:
                url1 = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
                img_urls_dict[url] = url1

        print("*******img_urls_dict****", img_urls_dict)
        item['content'], item['tags'] = Deal_Content.handleText(content, tagContet, img_urls_dict, title)
        print("************item['tags']********************",item['tags'])

        #type_cn    哪个类型的网站
        item['type_cn'] = None

        # #news    新闻来源、是那一个网站， 主页
        item['news'] = "中国财经首页"

        #type_no 就是 id
        item['type_no'] = None

        #print("item:////////////",item)
        yield item
