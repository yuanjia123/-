#baoji_shenzhen_shop

import scrapy
import re
import urllib.parse
from news_project.middlewares import Deal_Content
from news_project.items import NewsProjectItem

class baoji_shenzhen_shop(scrapy.Spider):
    name = 'baoji_shenzhen_shop'
    #allowed_domains = ['http://www.szbjsh.cn/']    #允许的页面最好不要定义  http://  这样的
    start_urls = ['http://www.szbjsh.cn/h-nl.html']

    #深圳宝鸡商会
    def parse(self, response):

        id, pid = Deal_Content.sql_read(response.url)

        home_url = response.xpath("//a[@class='fk-newsListTitle']/@href").extract()

        # 标题
        title = response.xpath("//a[@class='fk-newsListTitle']/@title").extract()
        print("打印title",title)
        # 时间
        time = response.xpath("//a[@class='fk-newsListDate']/text()").extract()

        j = 0
        for url in home_url:
            detail_url = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
            yield scrapy.Request(url=detail_url, callback=self.detail_parse,meta={'time': time[j], "title": title[j], 'id': id, 'pid': pid},dont_filter=True)  # 进入详细页面   dont_filter=True不重复进入访问过的页面
            j += 1


    def detail_parse(self,response):
        item = NewsProjectItem()
        meta = response.meta

        item['id'] = meta['id']

        item['pid'] = meta['pid']

        # 首页的url
        item['url'] = self.start_urls
        #print("首页的url",item['url'])

        # 标题
        title = meta['title']
        item['title'] = meta['title']
        #print('标题',item['title'])

        # 标题的url
        item['title_url'] = response.url
        #print('标题的url',item['title_url'])

        # 标题时间
        item['time'] = meta['time']
        #print('标题时间',item['time'])

#----------------------------------------------------------------------------------------------------
        # 详细页面的内容

        etree = response.xpath('//div[@class="newsDetail newsDetailV2"]/div[not(@class ="middlePanel")]')
        tagContet = etree.extract()
        tagContet = ''.join(tagContet)

        content = etree.xpath('.//text()').extract()
        content = ''.join(content)
        img_urls = etree.xpath('.//img/@src').extract()

        img_urls_dict = {}
        for url in img_urls:
            if "http://" not in url:
                url1 = urllib.parse.urljoin(response.url, url)  # 拼接url的网址
                img_urls_dict[url] = url1

        print("*******img_urls****", img_urls_dict)
        item['content'], item['tags'] = Deal_Content.handleText(content, tagContet,img_urls_dict, title)
        print("************item['tags']********************", item['tags'])

        item['type_cn'] = '商会'

        # #news    新闻来源、是那一个网站， 主页
        item['news'] = '深圳宝鸡商会'

        # try:   #删除这个新闻下面的， 不需要的字段。
        # item['content'] = item['content'].replace(re.findall(
        # "margin:0px;padding:0px;max-width:100%;box-sizing:border-box;word-wrap:break-word;font-family:Arial, sans-serif;letter-spacing:0.54px;(.*)",
        # item['content'])[0], '')
        # item['content'] = item['content'].replace('http://3750334.s21i.faiusr.com/2/ABUIABACGAAg4LK33QUoqJeF4wcwkAI4ggE.jpg','')
        print('=======================', item['content'])
        item['content'] = item['content'].replace('<img src="http://0.ss.faisys.com/image/loading/dot.gif" width="300" height="300" alt="商会LOGO.jpg" / data-original="//3750334.s21i.faiusr.com/2/ABUIABACGAAgrdGb2AUo2NbhrAQwrAI4rAI.jpg">', '')
        item['content'] = item['content'].replace('<img src="http://3750334.s21i.faiusr.com/2/ABUIABACGAAg4LK33QUoqJeF4wcwkAI4ggE.jpg" width="272" height="130" alt="13.jpg">', '')
        item['content'] = item['content'].replace('<img src="http://3750334.s21i.faiusr.com/2/ABUIABACGAAg4LK33QUoqJeF4wcwkAI4ggE.jpg" width="272" height="130" alt="13.jpg" />', '')

        filePath = item['title'] + '1.html'
        with open(filePath, 'w', encoding='utf-8') as f:    #zidongchuangian
            f.write(item['content'])

        item['type_no'] = 33

        #新增字段
        item['association_id'] = 169
        yield item
