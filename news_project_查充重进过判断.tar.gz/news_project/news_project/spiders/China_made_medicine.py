# -*- coding: utf-8 -*-
import scrapy
import urllib.parse
from news_project.middlewares import Deal_Content
from news_project.items import NewsProjectItem

class chanyeSpider(scrapy.Spider):
    name = 'China_made_medicine'
    #allowed_domains = ['www.zyzhan.com']    #允许的页面最好不要定义  http://  这样的
    base_url = 'http://www.zyzhan.com'
    start_urls = ['http://www.zyzhan.com/news/t14/list.html']

    #中国制药网
    def parse(self, response):

        id, pid = Deal_Content.sql_read(response.url)

        list_news = response.xpath("//div[@class='mainLeftList']//dl//dt")
        for dl in list_news:
            # url
            title_url = dl.xpath("./a/@href").extract_first()
            detail_url = self.base_url + title_url

            # 标题
            title = dl.xpath("./a/text()").extract_first()

            print(detail_url,title)
            yield scrapy.Request(url=detail_url, callback=self.detail_parse,meta={'detail_url':detail_url,"title":title,'id':id,'pid':pid},dont_filter=True)  #进入详细页面

    def detail_parse(self,response):
        item = NewsProjectItem()
        meta = response.meta

        item['id'] = 127

        item['pid'] = 3

        # 首页的url
        item['url'] = self.start_urls
        #print("首页的url",item['url'])

        # 标题
        title = meta['title']
        item['title'] = meta['title']
        #print('标题',item['title'])

        # 标题的url
        item['title_url'] = meta['detail_url']
        #print('标题的url',item['title_url'])

        #标题时间
        item['time'] = response.xpath("//div[@class='newsTime']//dt/text()[1]").extract_first()
        #print('标题时间',item['time'])


#--------------------------------------------------------------------------------------------
        # 详细页面的内容
        etree = response.xpath('//div[@class="newsContent"]')
        tagContet = etree.extract()
        tagContet = ''.join(tagContet)  #把全文专成字符出纳类型

        content = etree.xpath('.//text()').extract()
        content = ''.join(content)
        img_urls = etree.xpath('.//img/@src').extract()   #图片的rul, 这个返回的是一个列表。

        img_urls_dict = {}
        for url in img_urls:
            if "http://" not in url:
                url1 = urllib.parse.urljoin(response.url, url)  # 照片url 拼接全域名的网址
                img_urls_dict[url] = url1

        print("*******img_urls_dict****", img_urls_dict)
        item['content'], item['tags'] = Deal_Content.handleText(content, tagContet, img_urls_dict, title)  #这个函数的作用就是， 在str类型的html里面替换 原来的url(没有加域名，不能直接访问)。把它换掉， 换成全域名的url., 返回（str）类型的html和百度打分
        print("************item['tags']********************", item['tags'])

        #9大产业
        item['type_cn'] = None

        # #news    新闻来源、是那一个网站， 主页
        item['news'] = '中国制药网'

        # type_no 就是 id
        item['type_no'] = None
        yield item